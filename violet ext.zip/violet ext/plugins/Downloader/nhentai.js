import axios from "axios"
import { extractImageThumb } from "baileys"
import fetch from "node-fetch"

let handler = async(m, { conn, args }) => {


} 

handler.command = ['nhentai','nhentaidl']
handler.tags = ['downloader']
handler.help = ['nhentaidl']
export default handler 
